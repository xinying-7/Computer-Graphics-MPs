function compileAndLinkGLSL(vs_source, fs_source) {
    let vs = gl.createShader(gl.VERTEX_SHADER)
    gl.shaderSource(vs, vs_source)
    gl.compileShader(vs)
    if (!gl.getShaderParameter(vs, gl.COMPILE_STATUS)) {
        console.error(gl.getShaderInfoLog(vs))
        throw Error("Vertex shader compilation failed")
    }

    let fs = gl.createShader(gl.FRAGMENT_SHADER)
    gl.shaderSource(fs, fs_source)
    gl.compileShader(fs)
    if (!gl.getShaderParameter(fs, gl.COMPILE_STATUS)) {
        console.error(gl.getShaderInfoLog(fs))
        throw Error("Fragment shader compilation failed")
    }

    // window.program = gl.createProgram()
    let program = gl.createProgram() //changed

    gl.attachShader(program, vs)
    gl.attachShader(program, fs)
    gl.linkProgram(program)
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
        console.error(gl.getProgramInfoLog(program))
        throw Error("Linking failed")
    }
    //added
    return program
}

function setupGeomery1(geom) {
    var triangleArray = gl.createVertexArray()
    gl.bindVertexArray(triangleArray)

    Object.entries(geom.attributes).forEach(([name,data]) => {
        let buf = gl.createBuffer()
        gl.bindBuffer(gl.ARRAY_BUFFER, buf)
        let f32 = new Float32Array(data.flat())
        gl.bufferData(gl.ARRAY_BUFFER, f32, gl.STATIC_DRAW)
        
        let loc = gl.getAttribLocation(window.program1, name) //edited
        gl.vertexAttribPointer(loc, data[0].length, gl.FLOAT, false, 0, 0)
        gl.enableVertexAttribArray(loc)
    })

    var indices = new Uint16Array(geom.triangles.flat())
    var indexBuffer = gl.createBuffer()
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indexBuffer)
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, indices, gl.STATIC_DRAW)

    return {
        mode: gl.TRIANGLES,
        count: indices.length,
        type: gl.UNSIGNED_SHORT,
        vao: triangleArray
    }
}

//cpu-based:
var positionbuf;

function setupGeomery2(geom) {
    var triangleArray = gl.createVertexArray()
    gl.bindVertexArray(triangleArray)

    Object.entries(geom.attributes).forEach(([name,data]) => { //this is a for loop
        let buf = gl.createBuffer() //array of data for each attribute
        if (name == "position") {
            positionbuf = buf
        }
        //the following 3 lines should be repeated for each frame
        gl.bindBuffer(gl.ARRAY_BUFFER, buf)
        let f32 = new Float32Array(data.flat())
        gl.bufferData(gl.ARRAY_BUFFER, f32, gl.DYNAMIC_DRAW) //edited
        
        let loc = gl.getAttribLocation(window.program3, name) //edited
        gl.vertexAttribPointer(loc, data[0].length, gl.FLOAT, false, 0, 0)
        gl.enableVertexAttribArray(loc)
    })

    var indices = new Uint16Array(geom.triangles.flat())
    var indexBuffer = gl.createBuffer()
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indexBuffer)
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, indices, gl.DYNAMIC_DRAW)

    return {
        mode: gl.TRIANGLES,
        count: indices.length,
        type: gl.UNSIGNED_SHORT,
        vao: triangleArray
    }
}





// This script is long enough it should probably be in its own file; it's inline
// here simply to make this example easier to share as a single link.

/**
 * Animation callback for the first display. Should be invoked as 
 * `window.pending = requestAnimationFrame(draw1)`
 * and invokes that on itself as well; to stop it, call
 * `cancelAnimationFrame(window.pending)`
 *
 *
 */
function draw1(milliseconds) {


    gl.clearColor(0.075, 0.16, 0.292, 1)
    gl.clear(gl.COLOR_BUFFER_BIT) 
    gl.useProgram(window.program1)
    
    // define a float and passing it into vertex shader as "seconds"
    let secondsBindPoint = gl.getUniformLocation(window.program1, 'seconds')
    gl.uniform1f(secondsBindPoint, milliseconds/1000)

    //added: define a matrix and passing it into vertex shader as "scale1"
    s = Math.sin(milliseconds/1000) * 0.5
    let scale1 = gl.getUniformLocation(window.program1, 'scale1')
    gl.uniformMatrix4fv(scale1, false, new Float32Array([s,0,0,0, 0,s,0,0, 0,0,s,0, 0,0,0,1])) 

    //end

    gl.bindVertexArray(geom1.vao)
    gl.drawElements(geom1.mode, geom1.count, geom1.type, 0)
    
    // requestAnimationFrame calls its callback at as close to your screen's refresh rate as it can manage; its argument is a number of milliseconds that have elapsed since the page was first loaded.
    window.pending = requestAnimationFrame(draw1)
}
/**
 * Animation callback for the second display. 
 *
 */
function draw2(milliseconds) {


    gl.clearColor(0.075, 0.16, 0.292, 1)
    gl.clear(gl.COLOR_BUFFER_BIT)
    gl.useProgram(window.program2)
    let secondsBindPoint = gl.getUniformLocation(window.program2, 'seconds')
    gl.uniform1f(secondsBindPoint, milliseconds/1000)
    const connection = gl.POINTS
    const offset = 0                          // unused here, but required
    const count = 6+(0|milliseconds/100)%100  // number of vertices to draw
    let countBindPoint = gl.getUniformLocation(window.program2, 'count')
    gl.uniform1i(countBindPoint, count)
    gl.drawArrays(connection, offset, count)
    window.pending = requestAnimationFrame(draw2)
}


function draw3(milliseconds) {


    gl.clearColor(0.075, 0.16, 0.292, 1)
    gl.clear(gl.COLOR_BUFFER_BIT) 
    gl.useProgram(window.program3)
    
    // define a float and passing it into vertex shader as "seconds"
    let secondsBindPoint = gl.getUniformLocation(window.program3, 'seconds')
    gl.uniform1f(secondsBindPoint, milliseconds/1000)

    

    gl.bindVertexArray(geom3.vao)
    //here
    // modify vertex data every frame
    //to only change the position, use if name == position
    Object.entries(window.data3.attributes).forEach(([name,data]) => {
        if (name == "position") {
            var newdata = []
            var count = 0
            data.forEach(([x,y]) => {
                if (count < 6) {
                    x = x+Math.cos(milliseconds/1000)
                    y = y*Math.sin(milliseconds/1000-100) 
                }
                newdata.push([x,y])
                count += 1
            })
            
            let f32 = new Float32Array(newdata.flat()) //?
            gl.bindBuffer(gl.ARRAY_BUFFER, positionbuf)
            gl.bufferData(gl.ARRAY_BUFFER, f32, gl.DYNAMIC_DRAW)
        }
    })
    gl.drawElements(geom3.mode, geom3.count, geom3.type, 0)
    
    // requestAnimationFrame calls its callback at as close to your screen's refresh rate as it can manage; its argument is a number of milliseconds that have elapsed since the page was first loaded.
    window.pending = requestAnimationFrame(draw3)
}

function draw4(milliseconds) {


    gl.clearColor(0.075, 0.16, 0.292, 1)
    gl.clear(gl.COLOR_BUFFER_BIT) 
    gl.useProgram(window.program4)
    
    // define a float and passing it into vertex shader as "seconds"
    let secondsBindPoint = gl.getUniformLocation(window.program4, 'seconds')
    gl.uniform1f(secondsBindPoint, milliseconds/1000)

    gl.bindVertexArray(geom4.vao)
    gl.drawElements(geom4.mode, geom4.count, geom4.type, 0)
    
    // requestAnimationFrame calls its callback at as close to your screen's refresh rate as it can manage; its argument is a number of milliseconds that have elapsed since the page was first loaded.
    window.pending = requestAnimationFrame(draw4)
}

function draw5(milliseconds) {
    gl.clearColor(0.075, 0.16, 0.292, 1)
    gl.clear(gl.COLOR_BUFFER_BIT)
    gl.useProgram(window.program5)

    //define  seconds
    let secondsBindPoint = gl.getUniformLocation(window.program5, 'seconds')
    gl.uniform1f(secondsBindPoint, milliseconds/1000)


    gl.bindVertexArray(geom5.vao)
    gl.drawElements(geom5.mode, geom5.count, geom5.type, 0)
    
    window.pending = requestAnimationFrame(draw5)
}

function draw6(milliseconds) {
  

    gl.clearColor(0.88, 0.33, 0.5, 0.9)
    gl.clear(gl.COLOR_BUFFER_BIT) 
    gl.useProgram(window.program6)
    
    // define a float and passing it into vertex shader as "seconds"
    let secondsBindPoint = gl.getUniformLocation(window.program6, 'seconds')
    gl.uniform1f(secondsBindPoint, milliseconds/1000)

    gl.bindVertexArray(geom6.vao)
    gl.drawElements(geom6.mode, geom6.count, geom6.type, 0)
    
    // requestAnimationFrame calls its callback at as close to your screen's refresh rate as it can manage; its argument is a number of milliseconds that have elapsed since the page was first loaded.
    window.pending = requestAnimationFrame(draw6)
}

//added for mouse response
function getMousePosition(event, canvas) {
    canvas = canvas || event.target
    var box = canvas.getBoundingClientRect()
    x = event.clientX - box.left
    y = event.clientY - box.top
    x = x * canvas.width  / canvas.clientWidth
    y = y * canvas.height / canvas.clientHeight
    return {x,y};  
  }


function draw7(milliseconds) {
    gl.clearColor(0.075, 0.16, 0.292, 1)
    
    //added:
    const positionLoc = gl.getAttribLocation(window.program7, "position")
    window.addEventListener('mousemove', e => {

        const pos = getMousePosition(e, gl.canvas)
      
        // convert pixel coordinates to WebGL clip space coordinates
        const xm = pos.x / gl.canvas.width  *  2 - 1
        const ym = pos.y / gl.canvas.height * -2 + 1

        gl.clear(gl.COLOR_BUFFER_BIT)
        gl.useProgram(window.program7)
      
        gl.bindVertexArray(geom3.vao)
        Object.entries(window.data3.attributes).forEach(([name,data]) => {
            if (name == "position") {
                var newdata = []
                var count = 0
                data.forEach(([x,y]) => {
                    if (count < 6) {
                        x = x+xm + Math.sin(xm)
                        y = y*Math.sin(ym)+ym
                    }
                    x = x+xm
                    y = y-ym
                    newdata.push([x,y])
                    count +=1
                    
                
                })
                
                let f32 = new Float32Array(newdata.flat()) 
                gl.bindBuffer(gl.ARRAY_BUFFER, positionbuf)
                gl.bufferData(gl.ARRAY_BUFFER, f32, gl.DYNAMIC_DRAW)
            }
            
        })
        gl.drawElements(geom3.mode, geom3.count, geom3.type, 0)
        
      })
      
    //end
    window.pending = requestAnimationFrame(draw7)
}

function draw8(milliseconds) {
  

    gl.clearColor(0.075, 0.16, 0.292, 0.5)
    gl.clear(gl.COLOR_BUFFER_BIT) 
    gl.useProgram(window.program8)

    let secondsBindPoint = gl.getUniformLocation(window.program8, 'seconds')
    gl.uniform1f(secondsBindPoint, milliseconds/1000)

    //added: define a rotation matrix that makes the leg of figure rotate
    s = Math.sin(milliseconds/1000) * 0.5
    let walk = gl.getUniformLocation(window.program8, 'walk')
    gl.uniformMatrix4fv(walk, false, m4rotY(45*Math.sin(s*0.1))) 

    
    var vertices = [
        -0.5,-0.5,0.0,  //body
        0.0,0.0,0.0,
        0.0,0.0,0.0,
        0.5,-0.5,0.0,
        0.0,0.0,0.0,
        0.0,0.5,0.0,
        0.0,0.35,0.0,
        0.3,0.0,0.0,
        0.0,0.35,0.0,
        -0.3,0.0,0.0,

        0.0,0.5,0.0,   //head
        0.1,0.6,0.0,
        0.0,0.5,0.0,
        -0.1,0.6,0.0,
        0.0,0.7,0.0,
        0.1,0.6,0.0,
        0.0,0.7,0.0,
        -0.1,0.6,0.0
    ]
    
    var lineArray = gl.createVertexArray()
    gl.bindVertexArray(lineArray)

    var vertexBuf = gl.createBuffer()
    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuf)
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW)
    var loc = gl.getAttribLocation(window.program8, "position")
    gl.enableVertexAttribArray(loc)
    gl.vertexAttribPointer(loc, 3, gl.FLOAT, false, 0, 0)
    gl.drawArrays(gl.LINES, 0, vertices.length / 3)
    

    window.pending = requestAnimationFrame(draw8)
    
}



/** Callback for when the radio button selection changes */
function radioChanged() {
    let chosen = document.querySelector('input[name="example"]:checked').value
    cancelAnimationFrame(window.pending)
    window.pending = requestAnimationFrame(window['draw'+chosen])
}

/** Resizes the canvas to be a square that fits on the screen with at least 20% vertical padding */
function resizeCanvas() {
    let c = document.querySelector('canvas')
    c.width = c.parentElement.clientWidth
    c.height = document.documentElement.clientHeight * 0.8
    console.log(c.width, c.height)
    if (c.width > c.height) c.width = c.height
    else c.height = c.width
}




/**
 * Initializes WebGL and event handlers after page is fully loaded.
 * This example uses only `gl.clear` so it doesn't need any shaders, etc;
 * any real program would initialize models, shaders, and programs for each
 * display and store them for future use before calling `radioChanged` and
 * thus initializing the render.
 */


async function setup(event) {
    resizeCanvas()
    window.gl = document.querySelector('canvas').getContext('webgl2')

    // req1:
    let vs1 = await fetch('mp2-vertex.glsl').then(res => res.text())
    let fs1 = await fetch('mp2-fragment.glsl').then(res => res.text())
    window.program1 = compileAndLinkGLSL(vs1,fs1)
    let data = await fetch('mp2-geometry.json').then(r=>r.json())
    window.geom1 = setupGeomery1(data)

    //warmup:
    let vs2 = await fetch('warmup2-vertex.glsl').then(res => res.text())
    let fs2 = await fetch('warmup2-fragment.glsl').then(res => res.text())
    window.program2 = compileAndLinkGLSL(vs2,fs2)
    requestAnimationFrame(draw2)


    //cpu-based movement:
    let vs3 = await fetch('mp2-vertex-NoMatr.glsl').then(res => res.text())
    let fs3 = await fetch('mp2-fragment.glsl').then(res => res.text())
    window.program3 = compileAndLinkGLSL(vs3,fs3)
    window.data3 = await fetch('mp2-geometry.json').then(r=>r.json())
    window.geom3 = setupGeomery2(window.data3)

    //collision:
    let vs4 = await fetch('mp2-coll-vertex.glsl').then(res => res.text())
    let fs4 = await fetch('mp2-fragment.glsl').then(res => res.text())
    window.program4 = compileAndLinkGLSL(vs4,fs4)
    let data4 = await fetch('mp2-collision.json').then(r=>r.json())
    window.geom4 = setupGeomery1(data4)

    //gpu-based:
    let vs5 = await fetch('mp2-gpu-vertex.glsl').then(res => res.text())
    let fs5 = await fetch('mp2-fragment.glsl').then(res => res.text())
    window.program5 = compileAndLinkGLSL(vs5,fs5)
    let data5 = await fetch('mp2-geometry.json').then(r=>r.json())
    window.geom5 = setupGeomery1(data5)

    //psych:
    let vs6 = await fetch('mp2-psyc-vertex.glsl').then(res => res.text())
    let fs6 = await fetch('mp2-psyc-fragment.glsl').then(res => res.text())
    window.program6 = compileAndLinkGLSL(vs6,fs6)
    let data6 = await fetch('mp2-psy.json').then(r=>r.json())
    window.geom6 = setupGeomery1(data6)

    //mouse-response:
    let vs7 = await fetch('mp2-psyc-vertex.glsl').then(res => res.text())
    let fs7 = await fetch('mp2-fragment.glsl').then(res => res.text())
    window.program7 = compileAndLinkGLSL(vs7,fs7)
    let data7 = await fetch('mp2-geometry.json').then(r=>r.json())
    window.geom7 = setupGeomery1(data7)
    
    //walking:
    let vs8 = await fetch('mp2-walking-vertex.glsl').then(res => res.text())
    let fs8 = await fetch('mp2-walking-fragment.glsl').then(res => res.text())
    window.program8 = compileAndLinkGLSL(vs8,fs8)

    
    document.querySelectorAll('input[name="example"]').forEach(elem => {
        elem.addEventListener('change', radioChanged)
    })
    radioChanged()
}


window.addEventListener('load',setup)








