const IlliniBlue = new Float32Array([0.075, 0.16, 0.292, 1])
const IlliniOrange = new Float32Array([1, 0.373, 0.02, 1])
const IdentityMatrix = new Float32Array([1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1])

/**
 * Given the source code of a vertex and fragment shader, compiles them,
 * and returns the linked program.
 */
function compileAndLinkGLSL(vs_source, fs_source) {
    let vs = gl.createShader(gl.VERTEX_SHADER)
    gl.shaderSource(vs, vs_source)
    gl.compileShader(vs)
    if (!gl.getShaderParameter(vs, gl.COMPILE_STATUS)) {
        console.error(gl.getShaderInfoLog(vs))
        throw Error("Vertex shader compilation failed")
    }

    let fs = gl.createShader(gl.FRAGMENT_SHADER)
    gl.shaderSource(fs, fs_source)
    gl.compileShader(fs)
    if (!gl.getShaderParameter(fs, gl.COMPILE_STATUS)) {
        console.error(gl.getShaderInfoLog(fs))
        throw Error("Fragment shader compilation failed")
    }

    let program = gl.createProgram()
    gl.attachShader(program, vs)
    gl.attachShader(program, fs)
    gl.linkProgram(program)
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
        console.error(gl.getProgramInfoLog(program))
        throw Error("Linking failed")
    }
    
    return program
}

/**
 * Sends per-vertex data to the GPU and connects it to a VS input
 * 
 * @param data    a 2D array of per-vertex data (e.g. [[x,y,z,w],[x,y,z,w],...])
 * @param program a compiled and linked GLSL program
 * @param vsIn    the name of the vertex shader's `in` attribute
 * @param mode    (optional) gl.STATIC_DRAW, gl.DYNAMIC_DRAW, etc
 * 
 * @returns the ID of the buffer in GPU memory; useful for changing data later
 */
function supplyDataBuffer(data, program, vsIn, mode) {
    if (mode === undefined) mode = gl.STATIC_DRAW
    
    let buf = gl.createBuffer()
    gl.bindBuffer(gl.ARRAY_BUFFER, buf)
    let f32 = new Float32Array(data.flat())
    gl.bufferData(gl.ARRAY_BUFFER, f32, mode)
    
    let loc = gl.getAttribLocation(program, vsIn)
    gl.vertexAttribPointer(loc, data[0].length, gl.FLOAT, false, 0, 0)
    gl.enableVertexAttribArray(loc)
    
    return buf;
}


/**
 * Creates a Vertex Array Object and puts into it all of the data in the given
 * JSON structure, which should have the following form:
 * 
 * ````
 * {"triangles": a list of of indices of vertices
 * ,"attributes":
 *  {name_of_vs_input_1: a list of 1-, 2-, 3-, or 4-vectors, one per vertex
 *  ,name_of_vs_input_2: a list of 1-, 2-, 3-, or 4-vectors, one per vertex
 *  }
 * }
 * ````
 * 
 * @returns an object with four keys:
 *  - mode = the 1st argument for gl.drawElements
 *  - count = the 2nd argument for gl.drawElements
 *  - type = the 3rd argument for gl.drawElements
 *  - vao = the vertex array object for use with gl.bindVertexArray
 */
function setupGeomery(geom, program) {
    var triangleArray = gl.createVertexArray()
    gl.bindVertexArray(triangleArray)

    for(let name in geom.attributes) {
        let data = geom.attributes[name]
        supplyDataBuffer(data, program, name)
    }

    var indices = new Uint16Array(geom.triangles.flat())
    var indexBuffer = gl.createBuffer()
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indexBuffer)
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, indices, gl.STATIC_DRAW)

    return {
        mode: gl.TRIANGLES,
        count: indices.length,
        type: gl.UNSIGNED_SHORT,
        vao: triangleArray
    }
}




function addNormals(geom) {
    geom.attributes.normal = []
    for(let i=0; i<geom.attributes.position.length; i+=1) {
        geom.attributes.normal.push([0,0,0])
    }
    // console.log(geom.triangles.length, geom.attributes.position.length)
    for(let i=0; i<geom.triangles.length; i+=1) {
        let tri = geom.triangles[i]
        let p0 = geom.attributes.position[tri[0]]
        let p1 = geom.attributes.position[tri[1]]
        let p2 = geom.attributes.position[tri[2]]
        let e1 = sub(p1,p0)
        let e2 = sub(p2,p0)
        let n = cross(e1,e2)
        if (n[2] < 0) {         //reverse negative normals+t
            n[0] = -n[0]
            n[1] = -n[1]
            n[2] = -n[2]
        }
        geom.attributes.normal[tri[0]] = add(geom.attributes.normal[tri[0]], n)
        geom.attributes.normal[tri[1]] = add(geom.attributes.normal[tri[1]], n)
        geom.attributes.normal[tri[2]] = add(geom.attributes.normal[tri[2]], n)
    }
    for(let i=0; i<geom.attributes.position.length; i+=1) {
        geom.attributes.normal[i] = normalize(geom.attributes.normal[i] )
    }
    
}

function generateTerrain(geom,sidelength) {
 
    for (let i = 0; i < sidelength; i+=1) {
        for  (let j = 0; j < sidelength; j+=1) {
            let x = 4.0/sidelength * i - 1.5
            let y = 4.0/sidelength * j - 1.5
            // console.log("x,y:",x,y)
            geom.attributes.position.push([x, y, 0])
            
            
        }
    }

    for (let i = 0; i < sidelength*sidelength; i+=1) {
        if ((i+1)%sidelength == 0) {
            // console.log("skip")
            continue
        }
        // console.log(i, i+1, i+sidelength)
        // console.log(i+1, i+sidelength, i+sidelength+1)
        geom.triangles.push([i, i+1, i+sidelength])
        geom.triangles.push([i+1, i+sidelength, i+sidelength+1])

        if (i + sidelength +1 == geom.attributes.position.length-1) {
            break
        }
    }
}

function generateSphere(geom, latitude, longitude) {

    let index = 0
    const grid = []
    geom.attributes.normal = []
    for (let i = 0; i <= latitude-1; i+=1) {
            const rowvert = []
            const v = i/(latitude-1)
            
            for (let j = 0; j <= longitude; j+=1) {
                const u = j / longitude
                let x = -1.5*Math.cos(u*2*Math.PI) * Math.sin(v*Math.PI)
                let y = 1.5*Math.cos(v*Math.PI)
                let z = 1.5*Math.sin(u*2*Math.PI) * Math.sin(v*Math.PI)
                geom.attributes.position.push([x, y, z])
                // console.log(x,y,z)
                geom.attributes.normal.push([x,y,z])
                
                rowvert.push(index)
                index += 1
            }
            grid.push(rowvert)
           
    }
 
    for (let i = 0; i < latitude-1; i+=1) {
        for (let j = 0; j < longitude; j+=1) {
            if (i != 0) {
                // console.log(grid[i][j+1], grid[i][j], grid[i+1][j+1])
                geom.triangles.push([grid[i][j+1], grid[i][j], grid[i+1][j+1]])
            }
            if (i != latitude-2) {
                // console.log(grid[i][j], grid[i+1][j], grid[i+1][j+1])
                geom.triangles.push([grid[i][j], grid[i+1][j], grid[i+1][j+1]])
            }
        }
    }

    for(let i=0; i<geom.attributes.position.length; i+=1) {
    
        geom.attributes.normal[i] = normalize(geom.attributes.normal[i] )
    }

}



function spWeathering(geom, iteration, sidelength) {
    for (let j = 0; j < iteration; j+=1) {
        let newposition = []
        for (let i =0; i< geom.attributes.position.length; i+=1) {
            //initialize neighbor z coordinates
            let z1 = geom.attributes.position[i][2]  //left neighbor in x
            let z2 = geom.attributes.position[i][2]  //right neighbor in x
            let z3 = geom.attributes.position[i][2]  //lower neighbor in y
            let z4 = geom.attributes.position[i][2]  //higher neighbor in y
            if ((i-sidelength) >= 0) {
                z1 = geom.attributes.position[i-sidelength][2]
            }
            if ((i+sidelength) < geom.attributes.position.length) {
                z2 = geom.attributes.position[i+sidelength][2]
            }
            if ((i-1) >= 0 && (i)%sidelength != 0) {
                z3 = geom.attributes.position[i-1][2] 
            }
            if ((i+1) < geom.attributes.position.length && (i+1)%sidelength != 0) {
                z4 = geom.attributes.position[i+1][2]
            }
            
            let averagez = (z1+z2+z3+z4)/4
            newposition.push([geom.attributes.position[i][0], geom.attributes.position[i][1], averagez])
        }

        geom.attributes.position = newposition
    }
    
}   



function randomFaulting(geom, fractures) {
    var delta = 0.5
    for (let k = 0; k < fractures; k+=1) {
        // console.log(geom.attributes.position[15])
        let xrange = geom.attributes.position[geom.attributes.position.length-1][0] - geom.attributes.position[0][0]
        let yrange = geom.attributes.position[geom.attributes.position.length-1][1] - geom.attributes.position[0][1]
        let x = Math.random() * xrange - xrange/2
        let y = Math.random() * yrange - yrange/2
        // console.log(x,y)
        var p = new Float32Array([x,y,0])
        var angle = Math.random() * Math.PI * 2
        var n = new Float32Array([Math.cos(angle), Math.sin(angle), 0])

        for (let i = 0; i < geom.attributes.position.length; i+=1) {
            var a = new Float32Array(geom.attributes.position[i])
            var test = dot(sub(a,p),n)
            
            if (test >= 0) {
                geom.attributes.position[i][2] += delta     //raise z
            } else {
                geom.attributes.position[i][2] -= delta     //lower z
            }
            

        }
        delta *= 1   //scale down
    }
   
}




function verticalSeparation(geom, c) {
    var xmin =  geom.attributes.position[0][0]
    var xmax =  geom.attributes.position[geom.attributes.position.length-1][0]
    var zmax = -99
    var zmin = 99
    for (let i =0; i< geom.attributes.position.length; i+=1) {
        let x = geom.attributes.position[i][0]
        let z = geom.attributes.position[i][2]
        // console.log(x,z, zmax, zmin)
        if (x > xmax) {
            xmax = x
        } else if (x < xmin) {
            xmin = x
        }
        if (z > zmax) {
            zmax = z
        } else if (z < zmin) {
            zmin = z
        }

    }

    // console.log("zmin and zmax:", zmin, zmax)
    var h = (xmax-xmin) * c
    if (h == 0) {
        return
    }
    for (let i =0; i< geom.attributes.position.length; i+=1) {
        let z = geom.attributes.position[i][2]
        geom.attributes.position[i][2] = (z-zmin)/(zmax-zmin) * h - h/2
    }
    
}

function findz(geom) {
    var zmax = -99
    var zmin = 99
    for (let i =0; i< geom.attributes.position.length; i+=1) {
        let z = geom.attributes.position[i][2]
     
        if (z > zmax) {
            zmax = z
        } else if (z < zmin) {
            zmin = z
        }

    }
    return [zmin, zmax]
}


function displayterrain(geom) {
    console.log("displaying geom")
    console.log(geom.attributes.position.length, geom.triangles.length)
    // console.log("h:",zvals[1]-zvals[0])
    console.log("positions:")
    for (let i =0; i< geom.attributes.position.length; i+=1) {
        console.log(geom.attributes.position[i])
        // console.log("k:", geom.attributes.position[i][2] - zvals[0])
        // console.log("k/h:" , (geom.attributes.position[i][2] - zvals[0])/(zvals[1]-zvals[0]))
    }
    console.log("triangles:")
    for (let i =0; i< geom.triangles.length; i+=1) {
        console.log(geom.triangles[i])
    }
    // console.log("normals:") 
    // for (let i =0; i< geom.attributes.normal.length; i+=1) {
    //     console.log(geom.attributes.normal[i])
    // }
    // console.log("neighbors:")
    // for (let i =0; i< geom.attributes.neighbors.length; i+=1) {
    //     console.log(geom.attributes.neighbors[i])
    // }
}


//required part
async function required(options) {
    
    let vs = await fetch('mp3-vertex.glsl').then(res => res.text())
    let fs = await fetch('mp3-fragment.glsl').then(res => res.text())
    window.program1 = compileAndLinkGLSL(vs,fs)
    gl.enable(gl.DEPTH_TEST)
    gl.enable(gl.BLEND)
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA)
    let plain = await fetch('mp3.json').then(res => res.json())
    
    generateTerrain(plain, options.resolution)
    randomFaulting(plain, options.slices)
    // displayterrain(plain)
    verticalSeparation(plain, 0.4)  // choosing c as 0.4
    addNormals(plain)
    window.geom1 = setupGeomery(plain, program1)
    fillScreen()
    window.addEventListener('resize', fillScreen)
    requestAnimationFrame(timeStep1)
}


function timeStep1(milliseconds) {
    let seconds = milliseconds / 1000;
    
    window.m = m4mul(m4rotY(seconds/5), m4rotX(-Math.PI/2))
    window.v = m4view([2,2,3], [0,0,0], [0,1,0])

    draw1()
    requestAnimationFrame(timeStep1)
}


function draw1() {
    // gl.clearColor(...IlliniBlue) // f(...[1,2,3]) means f(1,2,3)
    // gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT)
    gl.clearColor(...IlliniBlue) // f(...[1,2,3]) means f(1,2,3)
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT)
    gl.useProgram(program1)

    gl.bindVertexArray(geom1.vao)

    gl.uniform3fv(gl.getUniformLocation(program1, 'lightdir'), normalize([1,1,1]))
    gl.uniform4fv(gl.getUniformLocation(program1, 'color'), IlliniOrange)
    gl.uniformMatrix4fv(gl.getUniformLocation(program1, 'mv'), false, m4mul(v,m))
    gl.uniformMatrix4fv(gl.getUniformLocation(program1, 'p'), false, p)
    gl.drawElements(geom1.mode, geom1.count, geom1.type, 0)
}


//optional parts
async function shiny(options) {
    let vs = await fetch('mp3-vertex.glsl').then(res => res.text())
    let fs = await fetch('mp3-shiny-f.glsl').then(res => res.text())
    window.program2 = compileAndLinkGLSL(vs,fs)
    gl.enable(gl.DEPTH_TEST)
    gl.enable(gl.BLEND)
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA)
    let plain = await fetch('mp3.json').then(res => res.json())
    generateTerrain(plain, options.resolution)
    randomFaulting(plain, options.slices)
    // displayterrain(plain)
    verticalSeparation(plain, 0.4)  // choosing c as 0.4
    addNormals(plain)
    window.geom2 = setupGeomery(plain, program2)
    fillScreen()
    window.addEventListener('resize', fillScreen)
    requestAnimationFrame(timeStep2)
}



function timeStep2(milliseconds) {
    let seconds = milliseconds / 1000;
    
    window.m = m4mul(m4rotY(seconds/5), m4rotX(-Math.PI/2))
    window.v = m4view([2,2,3], [0,0,0], [0,1,0])

    draw2()
    requestAnimationFrame(timeStep2)
}

function draw2() {
    gl.clearColor(...IlliniBlue) // f(...[1,2,3]) means f(1,2,3)
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT)
    gl.useProgram(program2)

    gl.bindVertexArray(geom2.vao)

    let lightdir = normalize([1,1,1])
    let halfway = normalize(add(lightdir, [0,0,1]))
    gl.uniform3fv(gl.getUniformLocation(program2, 'lightdir'), lightdir)
    gl.uniform3fv(gl.getUniformLocation(program2, 'halfway'), halfway)
    gl.uniform3fv(gl.getUniformLocation(program2, 'lightcolor'), [1,1,1])

    lightdir = normalize([-2,0,1])
    halfway = normalize(add(lightdir, [0,0,1]))
    gl.uniform3fv(gl.getUniformLocation(program2, 'lightdir2'), lightdir)
    gl.uniform3fv(gl.getUniformLocation(program2, 'halfway2'), halfway)
    gl.uniform3fv(gl.getUniformLocation(program2, 'lightcolor2'), [1,1,1])


    gl.uniform4fv(gl.getUniformLocation(program2, 'color'), IlliniOrange)
    gl.uniformMatrix4fv(gl.getUniformLocation(program2, 'mv'), false, m4mul(v,m))
    gl.uniformMatrix4fv(gl.getUniformLocation(program2, 'p'), false, p)
    gl.drawElements(geom2.mode, geom2.count, geom2.type, 0)

}




async function colorramp(options) {
    
    let vs = await fetch('mp3-colorramp-v.glsl').then(res => res.text())
    let fs = await fetch('mp3-colorramp-f.glsl').then(res => res.text())
    window.program3 = compileAndLinkGLSL(vs,fs)
    gl.enable(gl.DEPTH_TEST)
    gl.enable(gl.BLEND)
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA)
    let plain = await fetch('mp3.json').then(res => res.json())
    
    generateTerrain(plain, options.resolution)
    randomFaulting(plain, options.slices)
    verticalSeparation(plain, 0.4)  // choosing c as 0.4
    window.zvals = findz(plain)     //find zmin zmax and pass it into frag shader
    // displayterrain(plain)
    addNormals(plain)
    window.geom3 = setupGeomery(plain, program3)
    fillScreen()
    window.addEventListener('resize', fillScreen)
    requestAnimationFrame(timeStep3)
}


function timeStep3(milliseconds) {
    let seconds = milliseconds / 1000;
    
    window.m = m4mul(m4rotY(seconds/5), m4rotX(-Math.PI/2))
    window.v = m4view([2,2,3], [0,0,0], [0,1,0])

    draw3()
    requestAnimationFrame(timeStep3)
}



function draw3() {
    
    gl.clearColor(...IlliniBlue) // f(...[1,2,3]) means f(1,2,3)
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT)
    gl.useProgram(program3)

    gl.bindVertexArray(geom3.vao)

    // console.log("zvals:", zvals[0], zvals[1])

    //maybe calculate zmin and zmax inside this function instead of outside?
    //why is color different each time create new terrain?
    //why not interpolated

    gl.uniform1f(gl.getUniformLocation(program3, 'zmin'), zvals[0])
    gl.uniform1f(gl.getUniformLocation(program3, 'zmax'), zvals[1])

    gl.uniform3fv(gl.getUniformLocation(program3, 'lightdir'), normalize([1,1,1]))
    gl.uniform4fv(gl.getUniformLocation(program3, 'color'), IlliniOrange)
    gl.uniformMatrix4fv(gl.getUniformLocation(program3, 'mv'), false, m4mul(v,m))
    gl.uniformMatrix4fv(gl.getUniformLocation(program3, 'p'), false, p)
    gl.drawElements(geom3.mode, geom3.count, geom3.type, 0)
}




async function rockycliff(options) {
    let vs = await fetch('mp3-cliff-v.glsl').then(res => res.text())
    let fs = await fetch('mp3-cliff-f.glsl').then(res => res.text())
    window.program4 = compileAndLinkGLSL(vs,fs)
    gl.enable(gl.DEPTH_TEST)
    gl.enable(gl.BLEND)
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA)
    let plain = await fetch('mp3.json').then(res => res.json())
    generateTerrain(plain, options.resolution)
    randomFaulting(plain, options.slices)
    verticalSeparation(plain, 0.4)  // choosing c as 0.4
    addNormals(plain)
    // displayterrain(plain)
    window.geom4 = setupGeomery(plain, program4)
    fillScreen()
    window.addEventListener('resize', fillScreen)
    requestAnimationFrame(timeStep4)
}


function timeStep4(milliseconds) {
    let seconds = milliseconds / 1000;
    
    window.m = m4mul(m4rotY(seconds/5), m4rotX(-Math.PI/2))
    window.v = m4view([2,2,3], [0,0,0], [0,1,0])

    draw4()
    requestAnimationFrame(timeStep4)
}

function draw4() {
    gl.clearColor(...IlliniBlue) // f(...[1,2,3]) means f(1,2,3)
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT)
    gl.useProgram(program4)

    gl.bindVertexArray(geom4.vao)

    let lightdir = normalize([1,1,1])
    let halfway = normalize(add(lightdir, [0,0,1]))
    gl.uniform3fv(gl.getUniformLocation(program4, 'lightdir'), lightdir)
    gl.uniform3fv(gl.getUniformLocation(program4, 'halfway'), halfway)
    gl.uniform3fv(gl.getUniformLocation(program4, 'lightcolor'), [1,1,1])

    lightdir = normalize([-2,0,1])
    halfway = normalize(add(lightdir, [0,0,1]))
    gl.uniform3fv(gl.getUniformLocation(program4, 'lightdir2'), lightdir)
    gl.uniform3fv(gl.getUniformLocation(program4, 'halfway2'), halfway)
    gl.uniform3fv(gl.getUniformLocation(program4, 'lightcolor2'), [1,0.85,1])


    gl.uniform4fv(gl.getUniformLocation(program4, 'color'), IlliniOrange)
    gl.uniformMatrix4fv(gl.getUniformLocation(program4, 'mv'), false, m4mul(v,m))
    gl.uniformMatrix4fv(gl.getUniformLocation(program4, 'p'), false, p)

  


    gl.drawElements(geom4.mode, geom4.count, geom4.type, 0)

}


async function weathering(options) {
    
    let vs = await fetch('mp3-vertex.glsl').then(res => res.text())
    let fs = await fetch('mp3-fragment.glsl').then(res => res.text())
    window.program5 = compileAndLinkGLSL(vs,fs)
    gl.enable(gl.DEPTH_TEST)
    gl.enable(gl.BLEND)
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA)
    let plain = await fetch('mp3.json').then(res => res.json())
    
    generateTerrain(plain, options.resolution)
    randomFaulting(plain, options.slices)
    verticalSeparation(plain, 0.4)  // choosing c as 0.4
    spWeathering(plain, options.iteration, options.resolution)
    addNormals(plain)
    // displayterrain(plain)
    window.geom5 = setupGeomery(plain, program5)
    fillScreen()
    window.addEventListener('resize', fillScreen)
    requestAnimationFrame(timeStep5)
}





function timeStep5(milliseconds) {
    let seconds = milliseconds / 1000;
    
    window.m = m4mul(m4rotY(seconds/5), m4rotX(-Math.PI/2))
    window.v = m4view([2,2,3], [0,0,0], [0,1,0])

    draw5()
    requestAnimationFrame(timeStep5)
}


function draw5() {
    
    gl.clearColor(...IlliniBlue) // f(...[1,2,3]) means f(1,2,3)
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT)
    gl.useProgram(program5)

    gl.bindVertexArray(geom5.vao)

    gl.uniform3fv(gl.getUniformLocation(program5, 'lightdir'), normalize([1,1,1]))
    gl.uniform4fv(gl.getUniformLocation(program5, 'color'), IlliniOrange)
    gl.uniformMatrix4fv(gl.getUniformLocation(program5, 'mv'), false, m4mul(v,m))
    gl.uniformMatrix4fv(gl.getUniformLocation(program5, 'p'), false, p)
    gl.drawElements(geom5.mode, geom5.count, geom5.type, 0)
}



async function sphere(options) {
    
    let vs = await fetch('mp3-vertex.glsl').then(res => res.text())
    let fs = await fetch('mp3-fragment.glsl').then(res => res.text())
    window.program6 = compileAndLinkGLSL(vs,fs)
    gl.enable(gl.DEPTH_TEST)
    gl.enable(gl.BLEND)
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA)
    let plain = await fetch('mp3.json').then(res => res.json())
    
    generateSphere(plain, options.latitude, options.longitude)

    // displayterrain(plain)
    window.geom6 = setupGeomery(plain, program6)
    fillScreen()
    window.addEventListener('resize', fillScreen)
    requestAnimationFrame(timeStep6)
}





function timeStep6(milliseconds) {
    let seconds = milliseconds / 1000;
    
    window.m = m4mul(m4rotY(seconds/2), m4rotX(-Math.PI/2))
    window.v = m4view([2,2,3], [0,0,0], [0,1,0])

    draw6()
    requestAnimationFrame(timeStep6)
}


function draw6() {
    
    gl.clearColor(...IlliniBlue) // f(...[1,2,3]) means f(1,2,3)
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT)
    gl.useProgram(program6)

    gl.bindVertexArray(geom6.vao)

    gl.uniform3fv(gl.getUniformLocation(program6, 'lightdir'), normalize([1,1,1]))
    gl.uniform4fv(gl.getUniformLocation(program6, 'color'), IlliniOrange)
    gl.uniformMatrix4fv(gl.getUniformLocation(program6, 'mv'), false, m4mul(v,m))
    gl.uniformMatrix4fv(gl.getUniformLocation(program6, 'p'), false, p)
    gl.drawElements(geom6.mode, geom6.count, geom6.type, 0)
}




/** Resizes the canvas to completely fill the screen */
function fillScreen() {
    let canvas = document.querySelector('canvas')
    document.body.style.margin = '0'
    canvas.style.width = '100%'
    canvas.style.height = '100%'
    canvas.width = canvas.clientWidth
    canvas.height = canvas.clientHeight
    canvas.style.width = ''
    canvas.style.height = ''
    if (window.gl) {
        gl.viewport(0,0, canvas.width, canvas.height)
        window.p = m4perspNegZ(0.1, 10, 1, canvas.width, canvas.height)
    }
}



/**
 * Compile, link, other option-independent setup
 */
async function setup(event) {
    window.gl = document.querySelector('canvas').getContext('webgl2',
        // optional configuration object: see https://developer.mozilla.org/en-US/docs/Web/API/HTMLCanvasElement/getContext
        {antialias: false, depth:true, preserveDrawingBuffer:true}
    )
    // to do: more setup here

}


/**
 * Generate geometry, render the scene
 */
async function setupScene(scene, options) {
    console.log("To do: render",scene,"with options",options)
    if (scene == "terrain"){
        console.log("terrain chosen")
        required(options)
        
    } else if (scene == "shiny") {
        console.log("shiny chosen")
        shiny(options)
    } else if (scene == "colorramp") {
        console.log("colorramp chosen" ) 
        colorramp(options)
    } else if (scene == "rockycliff") {
        console.log("rocky cliff chosen") 
        rockycliff(options)
    } else if (scene == "weathering") {
        console.log("weathering chosen") 
        weathering(options)
    } else if (scene == "sphere") {
        console.log("sphere") 
        sphere(options)
    }
}

window.addEventListener('load', setup)

