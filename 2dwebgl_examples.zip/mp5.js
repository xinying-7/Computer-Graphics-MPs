const IlliniBlue = new Float32Array([0.075, 0.16, 0.292, 1])
const IlliniOrange = new Float32Array([1, 0.373, 0.02, 1])
const IdentityMatrix = new Float32Array([1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1])

/**
 * Given the source code of a vertex and fragment shader, compiles them,
 * and returns the linked program.
 */
function compileAndLinkGLSL(vs_source, fs_source) {
    let vs = gl.createShader(gl.VERTEX_SHADER)
    gl.shaderSource(vs, vs_source)
    gl.compileShader(vs)
    if (!gl.getShaderParameter(vs, gl.COMPILE_STATUS)) {
        console.error(gl.getShaderInfoLog(vs))
        throw Error("Vertex shader compilation failed")
    }

    let fs = gl.createShader(gl.FRAGMENT_SHADER)
    gl.shaderSource(fs, fs_source)
    gl.compileShader(fs)
    if (!gl.getShaderParameter(fs, gl.COMPILE_STATUS)) {
        console.error(gl.getShaderInfoLog(fs))
        throw Error("Fragment shader compilation failed")
    }

    let program = gl.createProgram()
    gl.attachShader(program, vs)
    gl.attachShader(program, fs)
    gl.linkProgram(program)
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
        console.error(gl.getProgramInfoLog(program))
        throw Error("Linking failed")
    }
    
    return program
}

/**
 * Sends per-vertex data to the GPU and connects it to a VS input
 * 
 * @param data    a 2D array of per-vertex data (e.g. [[x,y,z,w],[x,y,z,w],...])
 * @param program a compiled and linked GLSL program
 * @param vsIn    the name of the vertex shader's `in` attribute
 * @param mode    (optional) gl.STATIC_DRAW, gl.DYNAMIC_DRAW, etc
 * 
 * @returns the ID of the buffer in GPU memory; useful for changing data later
 */
function supplyDataBuffer(data, program, vsIn, mode) {
    if (mode === undefined) mode = gl.STATIC_DRAW
    
    let buf = gl.createBuffer()
    gl.bindBuffer(gl.ARRAY_BUFFER, buf)
    let f32 = new Float32Array(data.flat())
    gl.bufferData(gl.ARRAY_BUFFER, f32, mode)
    
    let loc = gl.getAttribLocation(program, vsIn)
    gl.vertexAttribPointer(loc, data[0].length, gl.FLOAT, false, 0, 0)
    gl.enableVertexAttribArray(loc)
    
    return buf;
}


/**
 * Creates a Vertex Array Object and puts into it all of the data in the given
 * JSON structure, which should have the following form:
 * 
 * ````
 * {"triangles": a list of of indices of vertices
 * ,"attributes":
 *  {name_of_vs_input_1: a list of 1-, 2-, 3-, or 4-vectors, one per vertex
 *  ,name_of_vs_input_2: a list of 1-, 2-, 3-, or 4-vectors, one per vertex
 *  }
 * }
 * ````
 * 
 * @returns an object with four keys:
 *  - mode = the 1st argument for gl.drawElements
 *  - count = the 2nd argument for gl.drawElements
 *  - type = the 3rd argument for gl.drawElements
 *  - vao = the vertex array object for use with gl.bindVertexArray
 */
function setupGeomery(geom, program) {
    var triangleArray = gl.createVertexArray()
    gl.bindVertexArray(triangleArray)

    for(let name in geom.attributes) {
        let data = geom.attributes[name]
        supplyDataBuffer(data, program, name)
    }

    var indices = new Uint16Array(geom.triangles.flat())
    var indexBuffer = gl.createBuffer()
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indexBuffer)
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, indices, gl.STATIC_DRAW)

    return {
        mode: gl.TRIANGLES,
        count: indices.length,
        type: gl.UNSIGNED_SHORT,
        vao: triangleArray
    }
}

var P_initial = []          //initial ball positions
var P_cur = []              //current/old ball positions and curr/old time
var P1_initial = []         //initial ball velocity
var P1 = []                 //first derivative(v) of p-cur 
var g = [0,0,-9.81] 
var P2 = []                 //second derivative(1/m * f) of p-cur 
var Pradius = []            //radii


function timeStep1(milliseconds) {
    window.seconds = milliseconds / 1000

    const deltaTime = seconds - previous          
    previous = seconds                         
    // console.log(previous, seconds)
    const fps = 1 / deltaTime             
    fpsElem.innerHTML = fps.toFixed(1) 


    // window.m = m4mul(m4mul(m4rotY(seconds/5), m4rotX(-Math.PI/2)),m4scale(0.5,0.5,0.5))
    window.v = m4mul(m4view([5,5,0], [0,0,0], [0,0,1]),m4rotZ(Math.PI/4))

    draw1()
    requestAnimationFrame(timeStep1)
}


// not yet updated!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1
function collision(p1,p2,v1,v2,w1,w2,e,r1,r2) {
    // calculate seperation
    const [x1,y1,z1] = p1
    const [x2,y2,z2] = p2
    var d = [x1-x2, y1-y2, z1-z2]
    var dd = Math.sqrt(d[0]*d[0]+d[1]*d[1]+d[2]*d[2])  //abs(d)

    // get the unit vector of seperation(if seperation is less than sum of radius, and they are moving towards each other, continue, if not, return)
    if (d <= r1+r2) {
        var v = vectorSub(v1,v2)  //v1-v2
        if (dotProduct(v,d) <= 0) {           //moving towards each other
            var u = [d[0]/dd, d[1]/dd, d[2]/dd]  //unit vector of sep

            // use this unit vector to take a dot product to know how much velocity is along collision direction, s1 and s2
                        // subtract to know how much velocity is along the other direction(vertical to collision direction)
            var s1 = dotProduct(v1, u)
            var s2 = dotProduct(v2, u)

            var s = vectorSub(s1,s2)
            var vnew1 = [-w1 * (1 + e) * s[0], -w1 * (1 + e) * s[1], -w1 * (1 + e) * s[2]]
            var vnew2 = [w2 * (1 + e) * s[0], w2 * (1 + e) * s[1], w2 * (1 + e) * s[2]]
            // console.log("v updated!")
            return [vnew1, vnew2]
        }
    }

    return []  // no collision

}




//p2 is where collision happens on the wall
function wallcollision(p1,p2,v1,n,w1,e,r) { 
    if (n[0]==0 && n[1]==0) {
        // console.log("zcoll-----------------------------------------------------------------------")
    } else if (n[1]==0 && n[2]== 0) {
        // console.log("xcoll-------------------------------------------------------------------------")
    } else {
        // console.log("ycoll-------------------------------------------------------------------------")
    }
    
    // calculate seperation
    const [x1,y1,z1] = p1
    const [x2,y2,z2] = p2
    var d = [x2-x1, y2-y1, z2-z1]
    var dd = Math.sqrt(d[0]*d[0]+d[1]*d[1]+d[2]*d[2])  //abs(d)
    // console.log("p1p2:", p1,p2)
    // console.log("v1, n:",v1, n)
    // console.log("d:",d)
    // console.log("dd",dd)
    
    var v = [n[0]-v1[0], n[1]-v1[1], n[2]-v1[2]]        // here v2 is [0,0,0], so v = v1-v2 = v1 ? 
    // console.log("dotprodu:",dotProduct(v1,d))
    if (dotProduct(v1,d) <= 0) {           //moving towards each other
        // get the unit vector of seperation(if seperation is less than sum of radius, and they are moving towards each other, continue, if not, return)
        var u = [d[0]/dd, d[1]/dd, d[2]/dd]  //unit vector of sep

        // use this unit vector to take a dot product to know how much velocity is along collision direction, s1 and s2
                    // (not used here)subtract to know how much velocity is along the other direction(vertical to collision direction)
        
        var s1 = dotProduct(v1, u)          //compute the speed(scalar) in collision direction
        var s2 = 0                          //0??  Math.sqrt(n[0]*n[0] + n[1]*n[1] + n[2]*n[2])
        // console.log("s1s2:", s1,s2)
        var s = s1-s2       
        if (n[0]==0 && n[1]==0) {   //s1 is pointing in +-z direction
            if (n[2] > 0) {
                var vnew1 = [v1[0], v1[1], v1[2] - w1 * (1 + e) * s]        //hitting floor, add s on z
            } else {
                var vnew1 = [v1[0], v1[1], v1[2] -(- w1 * (1 + e) * s)]        //hitting ceiling, sub s on z
            }
            
        } else if (n[1]==0 && n[2]== 0){             
            if (n[0] > 0) {
                var vnew1 = [v1[0] - w1 * (1 + e) * s, v1[1], v1[2]]        //add s on x
            } else {
                var vnew1 = [v1[0] -(- w1 * (1 + e) * s), v1[1], v1[2]]        //sub s on x
            }
            
        } else {
            if (n[1] > 0 ) {
                var vnew1 = [v1[0], v1[1] - w1 * (1 + e) * s, v1[2]]        //add s on y
            } else {
                var vnew1 = [v1[0], v1[1] -(- w1 * (1 + e) * s), v1[2]]        //sub s on y
            }
            
        }
        
        // console.log("vnew:", vnew1)
        // console.log("v updated!--------------------------------------------------------------")
        return vnew1
    }
    
    // console.log("here")
    // console.log("dotprodu:",dotProduct(v1,d))
    // console.log("p1p2:", p1,p2)
    // console.log("v1, n:",v1, n)
    // console.log("d:",d)
    // console.log("dd",dd)
    return v1  // no collision, return original velocity

}





function dotProduct(v1, v2) {
    if (v1.length !== v2.length) {
      throw new Error('Vector dimensions must match.')
    }
  
    let result = 0
    for (let i = 0; i < v1.length; i++) {
      result += v1[i] * v2[i]
    }
    // console.log("dotresult:", result)
    return result
}
  

function vectorSub(v1, v2) {
    if (v1.length !== v2.length) {
      throw new Error('Vector dimensions must match.')
    }
  
    let result = []
    for (let i = 0; i < v1.length; i++) {
      result.push(v1[i] - v2[i])
    }
    // console.log("subresult:", result)
    return result
}
  


function draw1(milliseconds) {
 
    // console.log("1:", count)
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT)
    gl.useProgram(program1)
    gl.bindVertexArray(geom1.vao)
    // set up your view and projection matrices
    
    if (P_initial.length != 50) {
        console.log("sth wrong!")
        
    } else if (periodicTime > 7) {
        for (let i = 0; i < 50; i+=1) {
            console.log("reset at :",seconds)
            
            periodicTime = 0
            toSubtract = seconds
            P_cur[i][0] = P_initial[i][0]
            P_cur[i][1] = P_initial[i][1]
            P_cur[i][2] = P_initial[i][2]
            P_cur[i][3] = periodicTime       //time
            P1[i] = P1_initial[i]
            P2[i] = [0,0,-9.81]

            // load a model matrix for this particle's position and size
            var x = P_cur[i][0]
            var y = P_cur[i][1]
            var z = P_cur[i][2]
            var c = P_initial[i][3]
            var m = m4mul(m4trans(x,y, z), m4scale(0.2,0.2,0.2))
            
            gl.uniform3fv(gl.getUniformLocation(program1, 'lightdir'), normalize([1,1,1]))
            gl.uniform4fv(gl.getUniformLocation(program1, 'color'), c)
            gl.uniformMatrix4fv(gl.getUniformLocation(program1, 'mv'), false, m4mul(v,m))
            gl.uniformMatrix4fv(gl.getUniformLocation(program1, 'p'), false, p)
            gl.drawElements(geom1.mode, geom1.count, geom1.type, 0)
        }
        
    } else {
        // let tmpxyz = []     //for ball to ball collision checking
        // let v = []          //for ball to ball collision checking

        for (let i = 0; i < 50; i+=1) {
            periodicTime = seconds - toSubtract
            let deltaT = Math.min(0.1,periodicTime - P_cur[i][3])  //new time - old time(min to avoid deltaT to be too large when return form another page)
            let P_old = P_cur[i].slice(0,3)   //x,y,z
            let P_new = []
            let P1_new = []             // first derivative
            for (let j = 0; j < 3; j+=1) {
                P_new[j] = P_old[j] + P1[i][j] * deltaT
                P1_new[j] = P1[i][j] + P2[i][j] * deltaT
            }
            
            P_new.push(periodicTime)          //add old time term
            P_cur[i] = P_new
            P1[i] = P1_new
            
            // tmpxyz.push([P_cur[i][0],P_cur[i][1],P_cur[i][2]])
            // v.push([P1[i][0], P1[i][1], P1[i][2]])

            
            var x = P_cur[i][0]
            var y = P_cur[i][1]
            var z = P_cur[i][2]
            var r = Pradius[i]

            let n = [0,0,0]  //initialize
            let p2 = [0,0,0]
            if (checkInside([x,y,z],r) == 1) {    //check collision with front and back wall:
                if (x < 0) {
                    n = [2,0,0]           //check collision with floor:
                    p2 = [2,y,z]            //?
                } else {
                    n = [-2,0,0]          //check collision with ceiling:
                    p2 = [-2,y,z]
                }
                
                let result = wallcollision([x,y,z],p2,P1[i],n, 1, 0.7, r)
                if (result != P1[i]){
                    P1[i] = result
                    let f = [-0.001*result[0]*r*r, -0.001*result[1]*r*r, -0.001*result[2]*r*r]   //choose c to be 0.001, m to be 0.05
                    P2[i] = [f[0]/0.05,f[1]/0.05,(f[2]-9.81*0.05)/0.05]                         //update acceleration with drag
                }
            } else if (checkInside([x,y,z],r) == 2) { //check collision with left and right wall
                if (y < 0) {
                    n = [0,2,0]           //check collision with floor:
                    p2 = [x,2,z]            //?
                } else {
                    n = [0,-2,0]          //check collision with ceiling:
                    p2 = [x,-2,z]
                }
                
                let result = wallcollision([x,y,z],p2,P1[i],n, 1, 0.7, r)
                if (result != P1[i]){
                    P1[i] = result
                    let f = [-0.001*result[0]*r*r, -0.001*result[1]*r*r, -0.001*result[2]*r*r]   //choose c to be 0.001, m to be 0.05
                    P2[i] = [f[0]/0.05,f[1]/0.05,(f[2]-9.81*0.05)/0.05]
                }
            } else if (checkInside([x,y,z],r) == 3) { 
                if (z < 0) {
                    n = [0,0,2]           //check collision with floor:
                    p2 = [x,y,2]            //?
                } else {
                    n = [0,0,-2]          //check collision with ceiling:
                    p2 = [x,y,-2]
                }
                
                let result = wallcollision([x,y,z],p2,P1[i],n, 1, 0.7, r)
                if (result != P1[i]){
                    P1[i] = result
                    let f = [-0.001*result[0]*r*r, -0.001*result[1]*r*r, -0.001*result[2]*r*r]   //choose c to be 0.001, m to be 0.05
                    P2[i] = [f[0]/0.05,f[1]/0.05,(f[2]-9.81*0.05)/0.05]
                }
            } 

            
            var c = P_initial[i][3]
            var m = new Float32Array([r,0,0,0, 0,r,0,0, 0,0,r,0, x,y,z,1])
            
            gl.uniform3fv(gl.getUniformLocation(program1, 'lightdir'), normalize([1,1,1]))
            gl.uniform4fv(gl.getUniformLocation(program1, 'color'), c)
            gl.uniformMatrix4fv(gl.getUniformLocation(program1, 'mv'), false, m4mul(v,m))
            gl.uniformMatrix4fv(gl.getUniformLocation(program1, 'p'), false, p)
            gl.drawElements(geom1.mode, geom1.count, geom1.type, 0)
        }

        
        // for (let i = 0; i < 50; i+=1) { 
        //     for (let j = i; j < 50; j+=1) {
        //         let dx = tmpxyz[i][0]-tmpxyz[j][0]
        //         let dy = tmpxyz[i][1]-tmpxyz[j][1]
        //         let dz = tmpxyz[i][2]-tmpxyz[j][2]
        //         let distance = dx*dx+dy*dy+dz*dz
        //         if (distance < 0.1) {

        //         }

        //     }
        // }

        // for (let i = 0; i < 50; i+=1) {
        //     var x = P_cur[i][0]
        //     var y = P_cur[i][1]
        //     var z = P_cur[i][2]
        //     var c = P_initial[i][3]
        //     // load a model matrix for this particle's position and size
        //     var m = m4mul(m4trans(x,y,z), m4scale(0.2,0.2,0.2))
            
        //     gl.uniform3fv(gl.getUniformLocation(program1, 'lightdir'), normalize([1,1,1]))
        //     gl.uniform4fv(gl.getUniformLocation(program1, 'color'), c)
        //     gl.uniformMatrix4fv(gl.getUniformLocation(program1, 'mv'), false, m4mul(v,m))
        //     gl.uniformMatrix4fv(gl.getUniformLocation(program1, 'p'), false, p)
        //     gl.drawElements(geom1.mode, geom1.count, geom1.type, 0)
        // }
    }
    //only if overlapping with the celling and moving up, then collide
    //one collision per frame
    //loop through each pairs of balls 
    //if 3 balls collide, add the change in velocity together
}

/** Resizes the canvas to completely fill the screen */
function fillScreen() {
    let canvas = document.querySelector('canvas')
    document.body.style.margin = '0'
    canvas.style.width = '100%'
    canvas.style.height = '100%'
    canvas.width = canvas.clientWidth
    canvas.height = canvas.clientHeight
    canvas.style.width = ''
    canvas.style.height = ''
    if (window.gl) {
        gl.viewport(0,0, canvas.width, canvas.height)
        window.p = m4perspNegZ(0.1, 10, 1, canvas.width, canvas.height)
    }
}


/**
 * Compile, link, other option-independent setup
 */
async function setup(event) {
    window.gl = document.querySelector('canvas').getContext('webgl2')
 
    let vs = await fetch('mp5-v.glsl').then(res => res.text())
    let fs = await fetch('mp5-f.glsl').then(res => res.text())
    window.program1 = compileAndLinkGLSL(vs,fs)
    gl.enable(gl.DEPTH_TEST)
    gl.enable(gl.BLEND)
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA)
    let sphere = await fetch('sphere80.json').then(res => res.json())

   
    window.geom1 = setupGeomery(sphere, program1)
    fillScreen()
    window.addEventListener('resize', fillScreen)

    window.periodicTime = 0
    window.toSubtract = 0


    //generate 50 random position and colors
    for (let i = 0; i < 50; i+=1) {        

        let r = Math.random()*0.25+0.05
        let x = Math.random()*(4-2*r)-(2-r)
        let y = Math.random()*(4-2*r)-(2-r)  //make sure pts in a cube
        let z = Math.random()*(4-2*r)-(2-r)
        let v = [Math.random()*8-4, Math.random()*8-4, Math.random()*10-5]
        let c = new Float32Array([Math.random(), Math.random(), Math.random(), 1])  //color
        

        P_initial.push([x,y,z,c])
        P_cur.push([x,y,z,0])
        P1.push(v)        //initialize
        P1_initial.push(v)
        P2.push(g)
        Pradius.push(r)
        // console.log(r)
        // if (x>2 || x < -2 || y>2 || y < -2 || z > 2 || z < -2 ) {
        //     console.log("pos:",x,y,z)
        // }
        // console.log("pos:",x,y,z)
        // console.log("v:", v)
    }

    window.fpsElem = document.querySelector("#fps")
    window.previous = 0 //time of last frame
    
    requestAnimationFrame(timeStep1)
    
}


// return where the ball collide with the box
function checkInside(pt,r) {
    
    let x = pt[0]
    let y = pt[1]
    let z = pt[2]
    let range = 2-r
    if (x >= range || x <= -range) {   //check x,y
        // console.log("should collide with front or back walls")
        return 1        
    } else if (y >= range || y <= -range) {
        // console.log("should collide with left or right walls")
        return 2        
    } else if (z >= range || z <= -range) {
        // console.log("should collide wiht floor or ceiling:", z)
        return 3        //collide with ceiling, normal is -z, collide with floor, normal is z
    }
    return 0            //no collision
}


window.addEventListener('load',setup)