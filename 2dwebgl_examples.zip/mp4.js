const IlliniBlue = new Float32Array([0.075, 0.16, 0.292, 1])
const IlliniOrange = new Float32Array([1, 0.373, 0.02, 1])
const IdentityMatrix = new Float32Array([1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1])
const FogColor = new Float32Array([0.87, 0.89, 0.92, 1])


var plain = 
    {"triangles":
        [

        ]
    ,"attributes":
        {"position":
            [
            ]
            
    
        }
    }

var objgeom = 
    {"triangles":
        [

        ]
    ,"attributes":
        {"position":
            [
            ]
            
    
        }
    }


/**
 * Given the source code of a vertex and fragment shader, compiles them,
 * and returns the linked program.
 */
function compileAndLinkGLSL(vs_source, fs_source) {
    let vs = gl.createShader(gl.VERTEX_SHADER)
    gl.shaderSource(vs, vs_source)
    gl.compileShader(vs)
    if (!gl.getShaderParameter(vs, gl.COMPILE_STATUS)) {
        console.error(gl.getShaderInfoLog(vs))
        throw Error("Vertex shader compilation failed")
    }

    let fs = gl.createShader(gl.FRAGMENT_SHADER)
    gl.shaderSource(fs, fs_source)
    gl.compileShader(fs)
    if (!gl.getShaderParameter(fs, gl.COMPILE_STATUS)) {
        console.error(gl.getShaderInfoLog(fs))
        throw Error("Fragment shader compilation failed")
    }

    let program = gl.createProgram()
    gl.attachShader(program, vs)
    gl.attachShader(program, fs)
    gl.linkProgram(program)
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
        console.error(gl.getProgramInfoLog(program))
        throw Error("Linking failed")
    }
    
    return program
}

/**
 * Sends per-vertex data to the GPU and connects it to a VS input
 * 
 * @param data    a 2D array of per-vertex data (e.g. [[x,y,z,w],[x,y,z,w],...])
 * @param program a compiled and linked GLSL program
 * @param vsIn    the name of the vertex shader's `in` attribute
 * @param mode    (optional) gl.STATIC_DRAW, gl.DYNAMIC_DRAW, etc
 * 
 * @returns the ID of the buffer in GPU memory; useful for changing data later
 */
function supplyDataBuffer(data, program, vsIn, mode) {
    if (mode === undefined) mode = gl.STATIC_DRAW
    
    let buf = gl.createBuffer()
    gl.bindBuffer(gl.ARRAY_BUFFER, buf)
    let f32 = new Float32Array(data.flat())
    gl.bufferData(gl.ARRAY_BUFFER, f32, mode)
    
    let loc = gl.getAttribLocation(program, vsIn)
    gl.vertexAttribPointer(loc, data[0].length, gl.FLOAT, false, 0, 0)
    gl.enableVertexAttribArray(loc)
    
    return buf;
}


/**
 * Creates a Vertex Array Object and puts into it all of the data in the given
 * JSON structure, which should have the following form:
 * 
 * ````
 * {"triangles": a list of of indices of vertices
 * ,"attributes":
 *  {name_of_vs_input_1: a list of 1-, 2-, 3-, or 4-vectors, one per vertex
 *  ,name_of_vs_input_2: a list of 1-, 2-, 3-, or 4-vectors, one per vertex
 *  }
 * }
 * ````
 * 
 * @returns an object with four keys:
 *  - mode = the 1st argument for gl.drawElements
 *  - count = the 2nd argument for gl.drawElements
 *  - type = the 3rd argument for gl.drawElements
 *  - vao = the vertex array object for use with gl.bindVertexArray
 */
function setupGeomery(geom, program) {
    var triangleArray = gl.createVertexArray()
    gl.bindVertexArray(triangleArray)

    for(let name in geom.attributes) {
        let data = geom.attributes[name]
        supplyDataBuffer(data, program, name)
    }

    var indices = new Uint16Array(geom.triangles.flat())
    var indexBuffer = gl.createBuffer()
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indexBuffer)
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, indices, gl.STATIC_DRAW)

    return {
        mode: gl.TRIANGLES,
        count: indices.length,
        type: gl.UNSIGNED_SHORT,
        vao: triangleArray
    }
}

function setupOBJ(geom, program) {
    var triangleArray = gl.createVertexArray()
    gl.bindVertexArray(triangleArray)

    for(let name in geom.attributes) {
        let data = geom.attributes[name]
        supplyDataBuffer(data, program, name)
    }

    var indices = new Uint16Array(geom.triangles.flat())
    var indexBuffer = gl.createBuffer()
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indexBuffer)
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, indices, gl.STATIC_DRAW)

    return {
        mode: gl.TRIANGLES,
        count: indices.length,
        type: gl.UNSIGNED_SHORT,
        vao: triangleArray
    }
}




function addNormals(geom) {
    geom.attributes.normal = []
    for(let i=0; i<geom.attributes.position.length; i+=1) {
        geom.attributes.normal.push([0,0,0])
    }
    // console.log(geom.triangles.length, geom.attributes.position.length)
    for(let i=0; i<geom.triangles.length; i+=1) {
        let tri = geom.triangles[i]
        let p0 = geom.attributes.position[tri[0]]
        let p1 = geom.attributes.position[tri[1]]
        let p2 = geom.attributes.position[tri[2]]
        let e1 = sub(p1,p0)
        let e2 = sub(p2,p0)
        let n = cross(e1,e2)
        if (n[2] < 0) {         //reverse negative normals+t
            n[0] = -n[0]
            n[1] = -n[1]
            n[2] = -n[2]
        }
        geom.attributes.normal[tri[0]] = add(geom.attributes.normal[tri[0]], n)
        geom.attributes.normal[tri[1]] = add(geom.attributes.normal[tri[1]], n)
        geom.attributes.normal[tri[2]] = add(geom.attributes.normal[tri[2]], n)
    }
    for(let i=0; i<geom.attributes.position.length; i+=1) {
        geom.attributes.normal[i] = normalize(geom.attributes.normal[i] )
    }
    
}

function generateTerrain(geom,sidelength) {
 
    geom.attributes.aTexCoord = []
    for (let i = 0; i < sidelength; i+=1) {
        for  (let j = 0; j < sidelength; j+=1) {
            let x = 4.0/sidelength * i - 1.5
            let y = 4.0/sidelength * j - 1.5
            // console.log("x,y:",x,y)
            geom.attributes.position.push([x,y,0])
            // texture coordinates(s,t)
            geom.attributes.aTexCoord.push([x,y])
            
        }
    }

    for (let i = 0; i < sidelength*sidelength; i+=1) {
        if ((i+1)%sidelength == 0) {
            // console.log("skip")
            continue
        }
        // console.log(i, i+1, i+sidelength)
        // console.log(i+1, i+sidelength, i+sidelength+1)
        geom.triangles.push([i, i+1, i+sidelength])
        geom.triangles.push([i+1, i+sidelength, i+sidelength+1])

        if (i + sidelength +1 == geom.attributes.position.length-1) {
            break
        }
    }
}


function randomFaulting(geom, fractures) {
    var delta = 0.5
    for (let k = 0; k < fractures; k+=1) {
        // console.log(geom.attributes.position[15])
        let xrange = geom.attributes.position[geom.attributes.position.length-1][0] - geom.attributes.position[0][0]
        let yrange = geom.attributes.position[geom.attributes.position.length-1][1] - geom.attributes.position[0][1]
        let x = Math.random() * xrange - xrange/2
        let y = Math.random() * yrange - yrange/2
        // console.log(x,y)
        var p = new Float32Array([x,y,0])
        var angle = Math.random() * Math.PI * 2
        var n = new Float32Array([Math.cos(angle), Math.sin(angle), 0])

        for (let i = 0; i < geom.attributes.position.length; i+=1) {
            var a = new Float32Array(geom.attributes.position[i])
            var test = dot(sub(a,p),n)
            
            if (test >= 0) {
                geom.attributes.position[i][2] += delta     //raise z
            } else {
                geom.attributes.position[i][2] -= delta     //lower z
            }
            

        }
        delta *= 1   //scale down
    }
   
}



function verticalSeparation(geom, c) {
    var xmin =  geom.attributes.position[0][0]
    var xmax =  geom.attributes.position[geom.attributes.position.length-1][0]
    var zmax = -99
    var zmin = 99
    for (let i =0; i< geom.attributes.position.length; i+=1) {
        let x = geom.attributes.position[i][0]
        let z = geom.attributes.position[i][2]
        // console.log(x,z, zmax, zmin)
        if (x > xmax) {
            xmax = x
        } else if (x < xmin) {
            xmin = x
        }
        if (z > zmax) {
            zmax = z
        } else if (z < zmin) {
            zmin = z
        }

    }

    // console.log("zmin and zmax:", zmin, zmax)
    var h = (xmax-xmin) * c
    if (h == 0) {
        return
    }
    for (let i =0; i< geom.attributes.position.length; i+=1) {
        let z = geom.attributes.position[i][2]
        geom.attributes.position[i][2] = (z-zmin)/(zmax-zmin) * h - h/2
    }
    
}

function generateTexture(geom) {

    
    let img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = "farm.jpg";
    img.addEventListener('load', (event) => {
        // ...
        let slot = 0; // or a larger integer if this isn't the only texture
        let texture = gl.createTexture();
        gl.activeTexture(gl.TEXTURE0 + slot);
        gl.bindTexture(gl.TEXTURE_2D, texture);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.MIRRORED_REPEAT);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.MIRRORED_REPEAT);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);

        gl.texImage2D(
            gl.TEXTURE_2D, // destination slot
            0, // the mipmap level this data provides; almost always 0
            gl.RGBA, // how to store it in graphics memory
            gl.RGBA, // how it is stored in the image object
            gl.UNSIGNED_BYTE, // size of a single pixel-color in HTML
            img, // source data
        );
        gl.generateMipmap(gl.TEXTURE_2D) // lets you use a mipmapping min filter
    })
}



function spWeathering(geom, iteration, sidelength) {
    for (let j = 0; j < iteration; j+=1) {
        let newposition = []
        for (let i =0; i< geom.attributes.position.length; i+=1) {
            //initialize neighbor z coordinates
            let z1 = geom.attributes.position[i][2]  //left neighbor in x
            let z2 = geom.attributes.position[i][2]  //right neighbor in x
            let z3 = geom.attributes.position[i][2]  //lower neighbor in y
            let z4 = geom.attributes.position[i][2]  //higher neighbor in y
            if ((i-sidelength) >= 0) {
                z1 = geom.attributes.position[i-sidelength][2]
            }
            if ((i+sidelength) < geom.attributes.position.length) {
                z2 = geom.attributes.position[i+sidelength][2]
            }
            if ((i-1) >= 0 && (i)%sidelength != 0) {
                z3 = geom.attributes.position[i-1][2] 
            }
            if ((i+1) < geom.attributes.position.length && (i+1)%sidelength != 0) {
                z4 = geom.attributes.position[i+1][2]
            }
            
            let averagez = (z1+z2+z3+z4)/4
            newposition.push([geom.attributes.position[i][0], geom.attributes.position[i][1], averagez])
        }

        geom.attributes.position = newposition
    }
    
}   





function findBorder(geom) {
    var xmax = -99
    var xmin = 99
    var ymax = -99
    var ymin = 99
    var step = geom.attributes.position[1][1] - geom.attributes.position[0][1]  //distance between each points on grid
    for (let i =0; i< geom.attributes.position.length; i+=1) {
        let x = geom.attributes.position[i][0]
        let y = geom.attributes.position[i][1]
     
        if (x > xmax) {
            xmax = x
        } else if (x < xmin) {
            xmin = x
        }
        if (y > ymax) {
            ymax = y
        } else if (y < ymin) {
            ymin = y
        }

    }
    return [xmin, xmax, ymin, ymax, step]
}


//for finding z position of 4 nearest pt around camera(including bilinear interpolation)
function findNeighbor(geom, x,y, step) {
    let neighbor1 = [x,y]//[x-step, y-step] 
    let neighbor2 = [x,y]//[x+step, y-step]
    let neighbor3 = [x,y]//[x+step, y+step]
    let neighbor4 = [x,y]//[x-step, y+step]
    let n1 = false
    let n2 = false
    let n3 = false
    let n4 = false

    // console.log("step: ",step)

    for (let i =0; i< geom.attributes.position.length; i+=1) {
        let curx = geom.attributes.position[i][0]
        let cury = geom.attributes.position[i][1]
        let curz = geom.attributes.position[i][2]
        if (!n1 && curx <= x && curx >= x-step && cury <= y && cury >= y-step) {
            // console.log("1 updated:" ,curx, cury, curz)
            neighbor1 = [curx, cury, curz]
            n1 = true
        }
        if (!n2 && curx >= x && curx <= x+step && cury <= y && cury >= y-step) {
            // console.log("2 updated:" ,curx, cury, curz)
            neighbor2 = [curx, cury, curz]
            n2 = true
        }
        if (!n3 && curx >= x && curx <= x+step && cury >= y && cury <= y+step) {
            // console.log("3 updated:" ,curx, cury, curz)
            neighbor3 = [curx, cury, curz]
            n3 = true
        }
        if (!n4 && curx <= x && curx >= x-step && cury >= y && cury <= y+step) {
            // console.log("4 updated:" ,curx, cury, curz)
            neighbor4 = [curx, cury, curz]
            n4 = true
        }
        if (n1 && n2 && n3 && n4) {
            break
        }
    }


    //bilinear interpolation,  weights add up to 1
    let w1 = ((neighbor3[1]-y)/step) * ((neighbor3[0]-x)/step)
    let w2 = ((neighbor4[1]-y)/step) * ((x-neighbor4[0])/step)
    let w3 = ((y-neighbor1[1])/step) * ((x-neighbor1[0])/step)
    let w4 = ((y-neighbor2[1])/step) * ((neighbor2[0]-x)/step)

    let averagez = neighbor1[2]*w1 + neighbor2[2]*w2 + neighbor3[2]*w3 + neighbor4[2]*w4

    
    return [neighbor1, neighbor2, neighbor3, neighbor4, averagez]
}

function objToJson(text, geom) {
   
    
    const lines = text.split('\n')
    
    let firstline = true

    lines.forEach(line => {
 
        let words = line.split(' ')
        words = words.filter(elem => elem !== '')

        if (firstline) {
            if (words.length == 7) {
                geom.attributes.color = []
                // console.log("yes!")
            }
            firstline = false
        }
        
        if (line[0] == 'v') {
            
            geom.attributes.position.push([words[1], words[2], words[3]])
            if (words.length == 7) {
                
                geom.attributes.color.push([words[4], words[5], words[6]])
            }
            

        } else if (line[0] == 'f') {
            for (let i = 2; i < words.length - 1; i++) { //start from the second number
                
                geom.triangles.push([words[1]-1, words[i]-1, words[i+1]-1])  //since this is 1-based instead of 0-based, -1
                
            }
        }

    })
    // console.log("geom:", geom)
    // console.log("cl:", geom.attributes.color)
    
}


//generate terrain
async function required() {
   
    let vs = await fetch('mp4-v.glsl').then(res => res.text())
    let fs = await fetch('mp4-f.glsl').then(res => res.text())
    window.program1 = compileAndLinkGLSL(vs,fs)
    gl.enable(gl.DEPTH_TEST)
    gl.enable(gl.BLEND)
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA)

    window.gridsize = 100
    let fractures = 100
    generateTerrain(plain, window.gridsize)
    randomFaulting(plain, fractures)

    verticalSeparation(plain, 0.4)  // choosing c as 0.4
    spWeathering(plain, 1, window.gridsize)  //do some weathering
    addNormals(plain)

    window.borders = findBorder(plain) //xmin, xmax, ymin, ymax, step
    // console.log("borders:", borders)
    // displayterrain(plain)
    window.geom1 = setupGeomery(plain, program1)

    
    window.objcheck = false
    //OBJ
    //do modifications to obj file to make it seems like a json file

    let objname = 'example.obj'  //how to use example.obj???

    if (window.location.hash.substr(1) != '') {
        objname = window.location.hash.substr(1)
    }

    await fetch(objname)
    .then(res => {
        if (!res.ok) {
        throw new Error('Network response was not ok')
        }
        // handle successful response here
        objcheck = true
        console.log(objcheck)

    })
    
    window.objhascolor = false    

    if (objcheck== true) {
        console.log("here")
        //having new buffer for object
        let objfile = await fetch(objname).then(res => res.text())

        if (objfile.length != 0) {
            objToJson(objfile, objgeom)

            if (Array.isArray(objgeom.attributes.color)) {
                // console.log("good")
                objhascolor = true
                let vs = await fetch('mp4-obj-color-v.glsl').then(res => res.text())
                let fs = await fetch('mp4-obj-color-f.glsl').then(res => res.text())
                window.program2 = compileAndLinkGLSL(vs,fs)
            } else {
                let vs = await fetch('mp4-obj-v.glsl').then(res => res.text())
                let fs = await fetch('mp4-obj-f.glsl').then(res => res.text())
                window.program2 = compileAndLinkGLSL(vs,fs)
            }
            
            window.geom2 = setupGeomery(objgeom, program2)
        } else {
            objcheck = false
            console.log("example.obj is empty!")
        }
        
        
    }
    

    fillScreen()
    window.addEventListener('resize', fillScreen)
    generateTexture(plain)
    requestAnimationFrame(timeStep1)
    
}



function drawobj() {
    //for obj
    if (window.objcheck) {
        gl.useProgram(program2)

        gl.bindVertexArray(geom2.vao)

        
        let centerx = (borders[1]+borders[0])/2
        let centery = (borders[3]+borders[2])/2
        // console.log("here,",centerx, centery)
        let tmp = findNeighbor(plain, centerx,centery, borders[4])  //neighbor1, neighbor2, neighbor3, neighbor4, averagez
        let centerz = tmp[4]

        // console.log("borders:",borders)
        // console.log("neighbors:" ,tmp)
        // console.log("z:",centerz)
        
        let mm = m4mul(m4mul(m4rotX(-Math.PI/2), m4rotZ(-Math.PI)),m) //rotate m to be upright

        // move to center
        mm[12] = centerx
        mm[13] = centery
        mm[14] = centerz+0.6
        
        gl.uniform3fv(gl.getUniformLocation(program2, 'lightdir'), normalize([1,1,1]))
        if (!objhascolor) {
            gl.uniform4fv(gl.getUniformLocation(program2, 'color'), IlliniOrange)
        }
        gl.uniformMatrix4fv(gl.getUniformLocation(program2, 'mv'), false, m4mul(v, mm))
        gl.uniformMatrix4fv(gl.getUniformLocation(program2, 'p'), false, p)
        gl.drawElements(geom2.mode, geom2.count, geom2.type, 0)
    }
    
}


window.m = new Float32Array([1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1])
window.v = m4view([2,2,1], [1,1,0], [0,0,1])


function timeStep1(milliseconds) {
    let seconds = milliseconds / 1000;
    let xplus = new Float32Array([0,0,0,0, 0,0,0,0, 0,0,0,0, 0.02,0,0,0])
    let yplus = new Float32Array([0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0.02,0,0])
    let zplus = new Float32Array([0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0.02,0])

    if (keysBeingPressed['w']) {
        // console.log("w")
        window.v = add(window.v, zplus)
    }
    if (keysBeingPressed['s']) {
        // console.log("s")
        window.v = sub(window.v, zplus)
    }
    if (keysBeingPressed['a']) {
        // console.log("a")
        window.v = add(window.v, xplus)
    }
    if (keysBeingPressed['d']) {
        // console.log("d")
        window.v = sub(window.v, xplus)
    }
    if (keysBeingPressed['e']) {
        // console.log("e")
        window.v = sub(window.v, yplus)
    }
    if (keysBeingPressed['q']) {
        // console.log("q")
        window.v = add(window.v, yplus)
    }
    if (keysBeingPressed["ArrowLeft"]) {
        window.v = m4mul(m4rotY(-0.01), window.v);
    }
    if (keysBeingPressed["ArrowRight"]) {
        window.v = m4mul(m4rotY(0.01), window.v);
    }
    if (keysBeingPressed["ArrowUp"]) {
        window.v = m4mul(m4rotX(-0.01), window.v);
    }
    if (keysBeingPressed["ArrowDown"]) {
        window.v = m4mul(m4rotX(0.01), window.v);
    }

    //mode changing
    if (vehicularmode) {

        console.log("vehicularmode on!")
      
        //get a global camera position vector
        //z val is determined by bilinear interpolation of 4 nearest pts
        //and call m4view matrix
        //check if eye vector is out of bound
        
        window.neighbors =  findNeighbor(plain, 1,0, window.borders[4]) 
        window.height = (window.borders[1]-window.borders[0]) / window.gridsize
        let initialz = window.neighbors[4] + window.height
        // console.log(":", window.neighbors, initialz)
        window.eye = [1,0,initialz]
        window.center = [2,0,0]
        draw1()
        requestAnimationFrame(timeStep2)
        
    } else if (fogmode) {
        console.log("fogmode on!")
        draw3()
        requestAnimationFrame(timeStep3)
        // change y as upward direction?
    } else {
        draw1()
        requestAnimationFrame(timeStep1)
    }
    
}




function draw1() {
    
    gl.clearColor(...IlliniBlue) // f(...[1,2,3]) means f(1,2,3)
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT)
    gl.useProgram(program1)

    gl.bindVertexArray(geom1.vao)

    gl.uniform3fv(gl.getUniformLocation(program1, 'lightdir'), normalize([1,1,1]))
    gl.uniform4fv(gl.getUniformLocation(program1, 'color'), IlliniOrange)
    gl.uniformMatrix4fv(gl.getUniformLocation(program1, 'mv'), false, m4mul(v,m))
    gl.uniformMatrix4fv(gl.getUniformLocation(program1, 'p'), false, p)

    let bindPoint = gl.getUniformLocation(program1, 'aTextureIPlanToUse')
    gl.uniform1i(bindPoint, 0) // where `slot` is same it was in step 2 above

    let tmp = 0.0
    gl.uniform1f(gl.getUniformLocation(program1, 'fog'), tmp)

    // s,t?
    // gl.uniform2fv(gl.getUniformLocation(program1, 'aTexCoord'), new Float32Array([0,0]))
    

    gl.drawElements(geom1.mode, geom1.count, geom1.type, 0)

    drawobj()
    
}


//vehicular movement
function timeStep2(milliseconds) {
    
    let xplus = new Float32Array([0.001,0,0])
    let yplus = new Float32Array([0,0.001,0])
    let zplus = new Float32Array([0,0,0.001])

    let step = window.borders[4]

    if (keysBeingPressed['w']) {
        // console.log("w")
        window.eye = add(window.eye, xplus)
        window.center = add(window.center, xplus)
    }
    if (keysBeingPressed['s']) {
        // console.log("s")
        window.eye = sub(window.eye, xplus)
        window.center = sub(window.center, xplus)
    }
    if (keysBeingPressed['a']) {
        // console.log("a")
        window.eye = add(window.eye, yplus)
        window.center = add(window.center, yplus)
    }
    if (keysBeingPressed['d']) {
        // console.log("d")
        window.eye = sub(window.eye, yplus)
        window.center = sub(window.center, yplus)
    }

    //determine if camera goes out of the border of terrain
    if (window.eye[0] < window.borders[0] || window.eye[0] > window.borders[1] || window.eye[1] < window.borders[2] || window.eye[1] > window.borders[3]) {
        console.log("out of border, vehicular mode off! Back to flight mode!")
        vehicularmode = false
    } else {
        //update neighbors and height
        window.neighbors = findNeighbor(plain, window.eye[0], window.eye[1], step)
        window.eye[2] = window.neighbors[4] + window.height
        window.center[2] = window.neighbors[4] - window.height

        window.v = m4view(window.eye, window.center, [0,0,1])
    }

    

    //mode changing
    if (fogmode) {
        
        draw3()
        if (!vehicularmode) {
            requestAnimationFrame(timeStep1)
        } else {
            requestAnimationFrame(timeStep2)
        }
        
    } else if (vehicularmode) {
        draw1()
        requestAnimationFrame(timeStep2)
        
    } else {
        console.log("vehicular mode off!")
        draw1()
        requestAnimationFrame(timeStep1)
    }
    
}


function draw3() {
    
    gl.clearColor(...FogColor) // f(...[1,2,3]) means f(1,2,3)
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT)
    gl.useProgram(program1)

    gl.bindVertexArray(geom1.vao)

    gl.uniform3fv(gl.getUniformLocation(program1, 'lightdir'), normalize([1,1,1]))
    gl.uniform4fv(gl.getUniformLocation(program1, 'color'), IlliniOrange)
    gl.uniformMatrix4fv(gl.getUniformLocation(program1, 'mv'), false, m4mul(v,m))
    gl.uniformMatrix4fv(gl.getUniformLocation(program1, 'p'), false, p)

    let bindPoint = gl.getUniformLocation(program1, 'aTextureIPlanToUse')
    gl.uniform1i(bindPoint, 0) // where `slot` is same it was in step 2 above

    let tmp = 1.0
    gl.uniform1f(gl.getUniformLocation(program1, 'fog'), tmp)

    // s,t?
    // gl.uniform2fv(gl.getUniformLocation(program1, 'aTexCoord'), new Float32Array([0,0]))
    

    gl.drawElements(geom1.mode, geom1.count, geom1.type, 0)
    drawobj()
}


//fog mode
function timeStep3(milliseconds) {
    let seconds = milliseconds / 1000;
    let xplus = new Float32Array([0,0,0,0, 0,0,0,0, 0,0,0,0, 0.02,0,0,0])
    let yplus = new Float32Array([0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0.02,0,0])
    let zplus = new Float32Array([0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0.02,0])

    if (keysBeingPressed['w']) {
        // console.log("w")
        window.v = add(window.v, zplus)
    }
    if (keysBeingPressed['s']) {
        // console.log("s")
        window.v = sub(window.v, zplus)
    }
    if (keysBeingPressed['a']) {
        // console.log("a")
        window.v = add(window.v, xplus)
    }
    if (keysBeingPressed['d']) {
        // console.log("d")
        window.v = sub(window.v, xplus)
    }
    if (keysBeingPressed['e']) {
        // console.log("e")
        window.v = sub(window.v, yplus)
    }
    if (keysBeingPressed['q']) {
        // console.log("q")
        window.v = add(window.v, yplus)
    }
    if (keysBeingPressed["ArrowLeft"]) {
        window.v = m4mul(m4rotY(-0.01), window.v);
    }
    if (keysBeingPressed["ArrowRight"]) {
        window.v = m4mul(m4rotY(0.01), window.v);
    }
    if (keysBeingPressed["ArrowUp"]) {
        window.v = m4mul(m4rotX(-0.01), window.v);
    }
    if (keysBeingPressed["ArrowDown"]) {
        window.v = m4mul(m4rotX(0.01), window.v);
    }

    //mode changing
    if (vehicularmode) {

        console.log("vehicularmode on!")
        window.neighbors =  findNeighbor(plain, 1,0, window.borders[4]) 
        window.height = (window.borders[1]-window.borders[0]) / window.gridsize
        let initialz = window.neighbors[4] + window.height
        // console.log(":", window.neighbors, initialz)
        window.eye = [1,0,initialz]
        window.center = [2,0,0]
        draw3()
        requestAnimationFrame(timeStep2)
    } else if (fogmode) {
        
        draw3()
        requestAnimationFrame(timeStep3)
    } else {
        console.log("fogmode off!")
        draw1()
        requestAnimationFrame(timeStep1)
    }
    
}


//OBJ loading

async function OBJ() {
    // let vs = await fetch('mp4-v.glsl').then(res => res.text())
    // let fs = await fetch('mp4-f.glsl').then(res => res.text())
    // window.program1 = compileAndLinkGLSL(vs,fs)
    gl.enable(gl.DEPTH_TEST)
    gl.enable(gl.BLEND)
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA)

    let triangle = await fetch('triangle.obj').then(res => res.obj())//
    window.gridsize = 5
    let fractures = 5
    generateTerrain(plain, window.gridsize)
    randomFaulting(plain, fractures)

    verticalSeparation(plain, 0.4)  // choosing c as 0.4
    spWeathering(plain, 1, window.gridsize)
    addNormals(plain)
    displayterrain(plain)
    window.geom1 = setupGeomery(plain, program1)
    fillScreen()
    window.addEventListener('resize', fillScreen)
    generateTexture(plain)
    requestAnimationFrame(timeStep1)
}




  
  
function displayterrain(geom) {
    console.log("displaying geom")
    console.log(geom.attributes.position.length, geom.triangles.length)
    // console.log("h:",zvals[1]-zvals[0])
    console.log("positions:")
    for (let i =0; i< geom.attributes.position.length; i+=1) {
        console.log(geom.attributes.position[i])
        // console.log("k:", geom.attributes.position[i][2] - zvals[0])
        // console.log("k/h:" , (geom.attributes.position[i][2] - zvals[0])/(zvals[1]-zvals[0]))
    }
    console.log("triangles:")
    for (let i =0; i< geom.triangles.length; i+=1) {
        console.log(geom.triangles[i])
    }
    // console.log("normals:") 
    // for (let i =0; i< geom.attributes.normal.length; i+=1) {
    //     console.log(geom.attributes.normal[i])
    // }
    // console.log("neighbors:")
    // for (let i =0; i< geom.attributes.neighbors.length; i+=1) {
    //     console.log(geom.attributes.neighbors[i])
    // }
}



/** Resizes the canvas to completely fill the screen */
function fillScreen() {
    let canvas = document.querySelector('canvas')
    document.body.style.margin = '0'
    canvas.style.width = '100%'
    canvas.style.height = '100%'
    canvas.width = canvas.clientWidth
    canvas.height = canvas.clientHeight
    canvas.style.width = ''
    canvas.style.height = ''
    if (window.gl) {
        gl.viewport(0,0, canvas.width, canvas.height)
        window.p = m4perspNegZ(0.1, 10, 1, canvas.width, canvas.height)
    }
}




/**
 * Compile, link, other option-independent setup
 */
async function setup(event) {
    window.gl = document.querySelector('canvas').getContext('webgl2',
        // optional configuration object: see https://developer.mozilla.org/en-US/docs/Web/API/HTMLCanvasElement/getContext
        {antialias: false, depth:true, preserveDrawingBuffer:true}
    )
    // to do: more setup here
    required()
}


window.addEventListener('load',setup)

//key controls
window.keysBeingPressed = {}
window.addEventListener('keydown', event => keysBeingPressed[event.key] = true)
window.addEventListener('keyup', event => keysBeingPressed[event.key] = false)

let vehicularmode = false

window.addEventListener('keydown', function(event) {
  if (event.key === 'g') {

    vehicularmode = !vehicularmode; // toggle the boolean variable
    console.log("g:", vehicularmode)
  }
})

let fogmode = false

window.addEventListener('keydown', function(event) {
  if (event.key === 'f') {

    fogmode = !fogmode; // toggle the boolean variable
    console.log("f:", fogmode)
  }
})